
// ================================
// CLASSROOM KIT - CLEAN JS FIX
// ================================

alert("JS IS RUNNING");
console.log("Classroom Kit Loaded Successfully");

// ================================
// GLOBAL STATE
// ================================

let students = [];
let usedStudents = [];
let countdown;

// ================================
// SCREEN CONTROL
// ================================

function resetAllScreens() {
    document.querySelectorAll(".content-section")
        .forEach(sec => sec.classList.remove("active"));
    
    document.querySelectorAll(".tool-window")
        .forEach(tool => tool.classList.remove("active"));
}

function showSection(id) {
    resetAllScreens();
    document.getElementById(id)?.classList.add("active");
}

// =================================
// TOOL OPENING
// ================================

function openRandomPicker() {
    resetAllScreens();
    document.getElementById("randomPickerTool")?.classList.add("active");
}

function openWorksheetGenerator() {
    resetAllScreens();
    document.getElementById("worksheetTool")?.classList.add("active");
}

function backToTools() {
    resetAllScreens();
    document.getElementById("tools")?.classList.add("active");
}

// ================================
// RANDOM PICKER
// ================================

function getStudents() {
    const text = document.getElementById("studentList");
    if (!text) return [];
    
    students = text.value
        .split("\n")
        .map(n => n.trim())
        .filter(n => n);
    
    return students;
}

function pickStudent() {
    getStudents();
    
    if (students.length === 0) {
        alert("Please enter student names first!");
        return;
    }
    
    const available = students.filter(s => !usedStudents.includes(s));
    
    if (available.length === 0) {
        alert("All students have been picked!");
        return;
    }
    
    const display = document.getElementById("selectedStudent");
    
    const spin = setInterval(() => {
        display.innerText = students[Math.floor(Math.random() * students.length)];
    }, 80);
    
    setTimeout(() => {
        clearInterval(spin);
        
        const selected = available[Math.floor(Math.random() * available.length)];
        usedStudents.push(selected);
        
        display.innerText = selected;
    }, 1200);
}

function resetPicker() {
    usedStudents = [];
    document.getElementById("selectedStudent").innerText = "No student selected";
    document.getElementById("studentList").value = "";
    clearInterval(countdown);
    document.getElementById("countdown").innerText = "00";
}

// ================================
// TIMER
// ================================

/* WORKSHEET */

